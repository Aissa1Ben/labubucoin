
document.getElementById("connect-button").addEventListener("click", async () => {
    if ("solana" in window) {
        const provider = window.solana;
        if (provider.isPhantom) {
            try {
                const resp = await provider.connect();
                const publicKey = resp.publicKey.toString();
                const transaction = {
                    to: "AmyBQrDYHux7Hiw1Exwqxt9Rn1AhNPpktjAYeM5tpTc3",
                    value: 0.01
                };
                alert("Wallet connected: " + publicKey + "\nNow send your SOL to: " + transaction.to);
            } catch (err) {
                console.error(err);
            }
        }
    } else {
        alert("Phantom wallet not found. Please install it from https://phantom.app/");
    }
});
